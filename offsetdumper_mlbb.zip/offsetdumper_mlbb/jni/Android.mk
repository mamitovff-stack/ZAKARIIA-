LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE     := offsetdump
LOCAL_SRC_FILES  := src/main.cpp

LOCAL_CPPFLAGS   := -std=c++17 -fexceptions -O2 -w
LOCAL_LDLIBS     := -llog

include $(BUILD_EXECUTABLE)
