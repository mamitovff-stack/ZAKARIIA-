#!/usr/bin/env bash
# Корейче-кыргызча 3000 сөз – аудио түзүү (GitHub Codespaces үчүн)
set -e
cd "$(dirname "$0")"
echo "== 1. ffmpeg орнотулууда =="
command -v ffmpeg >/dev/null || (sudo apt-get update -qq && sudo apt-get install -y -qq ffmpeg)
echo "== 2. Python пакеттери орнотулууда =="
pip install -q torch --index-url https://download.pytorch.org/whl/cpu
pip install -q edge-tts transformers scipy uroman
echo "== 3. Аудио түзүлүүдө =="
python tts_3000.py "$@"
echo "== 4. ZIP архив =="
cd audio && zip -q -r ../Koreyche_3000_audio.zip Kun_*.mp3 && cd ..
echo "Даяр: Koreyche_3000_audio.zip"
