#!/usr/bin/env python3
"""
Корейче-кыргызча 3000 сөз -> күнүгө 30 сөздөн 100 MP3 файл.

Ар бир сөз: корейче (1-жолу) -> тыным -> корейче (2-жолу, жайыраак) -> тыным -> кыргызча -> узун тыным.

Корейче үн:  Microsoft Edge нейрон үнү (edge-tts), мисалы ko-KR-SunHiNeural
Кыргызча үн: Meta MMS-TTS (facebook/mms-tts-kir), компьютерде иштейт

Колдонуу:
    python tts_3000.py                 # 100 күндүн баарын түзүү
    python tts_3000.py --days 1-5      # 1-5 күндөрдү гана
    python tts_3000.py --only-ko       # кыргызча үнсүз, корейче гана
    python tts_3000.py --voice ko-KR-InJoonNeural   # эркек үн
    python tts_3000.py --fake          # текшерүү режими (үн ордуна сигнал)
"""
import argparse, asyncio, csv, os, re, shutil, subprocess, sys, tempfile

SR = 24000  # бардык бөлүктөр ушул жыштыкка келтирилет

def sh(cmd):
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        sys.exit("ffmpeg катасы:\n" + r.stderr[-1500:])

def to_wav(src, dst):
    sh(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-ac", "1", "-ar", str(SR), dst])

def silence(path, sec):
    sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
        f"anullsrc=r={SR}:cl=mono", "-t", str(sec), path])

def clean_kg(text):
    # кашаанын ичин алып салып, маанилерди үтүр менен окуйбуз
    t = re.sub(r"\([^)]*\)", "", text)
    parts = [p.strip(" ,") for p in t.split(";")]
    return ", ".join(p for p in parts if p)

def parse_days(s, maxday):
    if not s:
        return set(range(1, maxday + 1))
    out = set()
    for chunk in s.split(","):
        if "-" in chunk:
            a, b = chunk.split("-"); out |= set(range(int(a), int(b) + 1))
        else:
            out.add(int(chunk))
    return out

# ---------------- Корейче: edge-tts ----------------
async def ko_all(items, voice, outdir, fake):
    if fake:
        for no, text in items:
            p = os.path.join(outdir, f"ko_{no}.mp3")
            p2 = os.path.join(outdir, f"ko2_{no}.mp3")
            for q in (p, p2):
                if not os.path.exists(q):
                    sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                        "sine=frequency=660:duration=0.6", q])
        return
    import edge_tts
    sem = asyncio.Semaphore(6)

    async def one(no, text):
        for rate, name in (("-5%", f"ko_{no}.mp3"), ("-30%", f"ko2_{no}.mp3")):
            p = os.path.join(outdir, name)
            if os.path.exists(p) and os.path.getsize(p) > 0:
                continue
            for attempt in range(5):
                try:
                    async with sem:
                        await edge_tts.Communicate(text, voice, rate=rate).save(p)
                    break
                except Exception as ex:
                    if attempt == 4:
                        print(f"  ! {no} {text}: {ex}")
                    await asyncio.sleep(2 + attempt * 2)

    await asyncio.gather(*(one(no, t) for no, t in items))

# ---------------- Кыргызча: MMS-TTS ----------------
class KgTTS:
    def __init__(self, fake):
        self.fake = fake
        if fake:
            return
        import torch
        from transformers import VitsModel, AutoTokenizer
        self.torch = torch
        print("Кыргызча үн модели жүктөлүүдө (facebook/mms-tts-kir)…")
        self.model = VitsModel.from_pretrained("facebook/mms-tts-kir")
        self.tok = AutoTokenizer.from_pretrained("facebook/mms-tts-kir")
        self.rate = self.model.config.sampling_rate
        self.uroman = None
        if getattr(self.tok, "is_uroman", False):
            import uroman as ur
            self.uroman = ur.Uroman()

    def say(self, text, path):
        if os.path.exists(path) and os.path.getsize(path) > 0:
            return
        if self.fake:
            sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                "sine=frequency=330:duration=0.8", path])
            return
        import scipy.io.wavfile
        t = text.lower()
        if self.uroman:
            t = self.uroman.romanize_string(t)
        inputs = self.tok(t, return_tensors="pt")
        with self.torch.no_grad():
            wav = self.model(**inputs).waveform[0].numpy()
        scipy.io.wavfile.write(path, self.rate, wav)

# ---------------- Негизги иш ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="words.csv")
    ap.add_argument("--out", default="audio")
    ap.add_argument("--days", default="")
    ap.add_argument("--voice", default="ko-KR-SunHiNeural")
    ap.add_argument("--only-ko", action="store_true")
    ap.add_argument("--fake", action="store_true")
    a = ap.parse_args()

    if not shutil.which("ffmpeg"):
        sys.exit("ffmpeg табылган жок. Алгач орнотуңуз: sudo apt-get install -y ffmpeg")

    rows = []
    with open(a.csv, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            rows.append((int(r["№"]), int(r["Күн"]), r["Корейче"].strip(), r["Кыргызча"].strip()))
    maxday = max(r[1] for r in rows)
    days = parse_days(a.days, maxday)
    rows = [r for r in rows if r[1] in days]
    print(f"{len(rows)} сөз, {len(days)} күн.")

    os.makedirs(a.out, exist_ok=True)
    cache = os.path.join(a.out, "_cache"); os.makedirs(cache, exist_ok=True)

    print("1/3 Корейче үндөр түзүлүүдө…")
    asyncio.run(ko_all([(r[0], r[2]) for r in rows], a.voice, cache, a.fake))

    kg = None
    if not a.only_ko:
        print("2/3 Кыргызча үндөр түзүлүүдө…")
        kg = KgTTS(a.fake)
        for i, (no, day, ko, kgtext) in enumerate(rows, 1):
            kg.say(clean_kg(kgtext), os.path.join(cache, f"kg_{no}.wav"))
            if i % 100 == 0:
                print(f"   {i}/{len(rows)}")

    print("3/3 Күндүк MP3 файлдар чогултулууда…")
    tmp = tempfile.mkdtemp()
    s_short, s_long = os.path.join(tmp, "s1.wav"), os.path.join(tmp, "s2.wav")
    silence(s_short, 0.8); silence(s_long, 1.8)
    for day in sorted(days):
        day_rows = [r for r in rows if r[1] == day]
        dst = os.path.join(a.out, f"Kun_{day:03d}.mp3")
        if os.path.exists(dst):
            continue
        parts = []
        for no, _, ko, _ in day_rows:
            k1, k2 = os.path.join(cache, f"ko_{no}.mp3"), os.path.join(cache, f"ko2_{no}.mp3")
            if not (os.path.exists(k1) and os.path.exists(k2)):
                print(f"  ! {no} {ko}: корейче үн жок, өткөрүлдү"); continue
            w1, w2 = os.path.join(tmp, f"{no}a.wav"), os.path.join(tmp, f"{no}b.wav")
            to_wav(k1, w1); to_wav(k2, w2)
            parts += [w1, s_short, w2, s_short]
            if kg:
                wk = os.path.join(tmp, f"{no}c.wav")
                to_wav(os.path.join(cache, f"kg_{no}.wav"), wk)
                parts += [wk]
            parts += [s_long]
        lst = os.path.join(tmp, f"list{day}.txt")
        with open(lst, "w") as f:
            f.writelines(f"file '{p}'\n" for p in parts)
        sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst,
            "-ac", "1", "-ar", str(SR), "-b:a", "64k",
            "-metadata", f"title=Күн {day} (№{day_rows[0][0]}–{day_rows[-1][0]})",
            "-metadata", "album=Корей тили – 3000 сөз", "-metadata", f"track={day}", dst])
        print(f"   ✓ {os.path.basename(dst)}")
    shutil.rmtree(tmp)
    print(f"Даяр! Файлдар '{a.out}' папкасында.")

if __name__ == "__main__":
    main()
